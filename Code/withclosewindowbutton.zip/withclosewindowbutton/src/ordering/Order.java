package ordering;

import java.util.ArrayList;

/**
 * Order Class that contains items to be ordered. Contains the total for the
 * items.
 *
 * @author Dalton Rothenberger
 * @version November 27, 2018
 *
 */
public class Order {

    /**
     * Array that holds all the items in the order
     */
    private ArrayList<Item> _items;

    /**
     * Creates an Order object and instantiates the ArrayList of items
     *
     */
    public Order() {
        _items = new ArrayList<Item>();
    }

    /**
     * Adds an item to the items list
     *
     * @param toAdd The item to be added
     */
    public void addItem(Item toAdd) {
        _items.add(toAdd);

    }

    /**
     * Removes an item from the order
     *
     * @param index The index of the item to be removed
     * @return The item that was removed
     */
    public Item removeItem(int index) {

        Item toReturn = _items.remove(index);

        return toReturn;
    }

    /**
     * Calculates the sub total of the order
     *
     * @return The sub total of the order
     */
    public double calcSubTotal() {
        double toReturn = 0.0;

        for (int i = 0; i < _items.size(); i++) {
            toReturn += _items.get(i).getPrice() * _items.get(i).getQuantity();
        }

        return toReturn;
    }

    /**
     * Calculates the total of the order
     *
     * @param tax The tax for the order
     * @return The total cost of the order
     */
    public double calcTotal(double tax) {
        double toReturn = 0.0;

        for (int i = 0; i < _items.size(); i++) {
            toReturn += _items.get(i).getPrice() * _items.get(i).getQuantity();
            toReturn += _items.get(i).getPrice() * _items.get(i).getQuantity() * tax;
        }

        return toReturn;
    }

    /**
     * Allows access to the items in the order
     *
     * @return An array list containing the items in the order
     */
    public ArrayList<Item> getItems() {
        return _items;
    }

    /**
     * Creates a string representation of the order
     *
     * @return The string representation of the order
     */
    public String toString() {
        String order = "";
        for (int i = 0; i < _items.size(); i++) {

            order += String.format("%1$-25.25s \t %2$s\n", _items.get(i).getName(), _items.get(i).getQuantity());

        }
        return order;
    }

}
