package database;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dalton Rothenberger
 */
public class DB_UserInfo {

    public static void main(String[] args) throws SQLException {
//
//        Path currentRelativePath = Paths.get("");
//        String s = currentRelativePath.toAbsolutePath().toString();
//        s += "\\src\\database\\DMDatabase.accdb";
////
////        Connection conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
////        Statement state = conn.createStatement();
////        ResultSet rs = state.executeQuery("SELECT [Quantity] FROM [Inventory] WHERE [ItemName] = 'Blue Paper (500 Sheets)'");
////
////        rs.next();
////        System.out.println(rs.getString(1));
////
////        rs.close();
////        state.close();
////        conn.close();

//        System.out.println(getPassword("Beanssajda"));

        
    }

    /**
     * Allows access to the User Info Database table and looks for the password
     * of the user
     *
     * @param username The username of the user trying to log in
     * @return The password of the user
     */
    public static String getPassword(String username) throws SQLException {

        String toReturn = null;

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            rs = state.executeQuery("SELECT [Password] FROM [Credentials] WHERE [Username] = '" + username + "'");

            rs.next();
            System.out.println(rs.getString(1));

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

        return toReturn;
    }

}
