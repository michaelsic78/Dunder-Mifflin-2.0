package taxes;

import java.util.EnumMap;

/**
 * Singleton StateTaxMap that is a map which uses the state's two letter
 * abbreviation as the key and the tax rate is the value stored
 *
 * @author Dalton Rothenberger
 * @version November 27, 2018
 */
public class StateTaxMap {

    /**
     * EnumMap using the state abbreviation as the key and the tax rate as the
     * value stored
     */
    private EnumMap<States, Double> _stateTaxes = new EnumMap<States, Double>(States.class);

    /**
     * This is private so that the default constructor that Java would normally
     * create does not get created and there is no access to this constructor
     * outside of the inside of the class.
     */
    private StateTaxMap() {

        _stateTaxes.put(States.AL, .04);
        _stateTaxes.put(States.AK, .00);
        _stateTaxes.put(States.AZ, .056);
        _stateTaxes.put(States.AR, .065);
        _stateTaxes.put(States.CA, .0725);
        _stateTaxes.put(States.CO, .029);
        _stateTaxes.put(States.CT, .0635);
        _stateTaxes.put(States.DE, .0);
        _stateTaxes.put(States.FL, .06);
        _stateTaxes.put(States.GA, .04);
        _stateTaxes.put(States.HI, .04);
        _stateTaxes.put(States.ID, .06);
        _stateTaxes.put(States.IL, .0625);
        _stateTaxes.put(States.IN, .07);
        _stateTaxes.put(States.IA, .06);
        _stateTaxes.put(States.KS, .065);
        _stateTaxes.put(States.KY, .06);
        _stateTaxes.put(States.LA, .05);
        _stateTaxes.put(States.ME, .055);
        _stateTaxes.put(States.MD, .06);
        _stateTaxes.put(States.MA, .0625);
        _stateTaxes.put(States.MI, .06);
        _stateTaxes.put(States.MN, .06875);
        _stateTaxes.put(States.MS, .07);
        _stateTaxes.put(States.MO, .04225);
        _stateTaxes.put(States.MT, .0);
        _stateTaxes.put(States.NE, .055);
        _stateTaxes.put(States.NV, .0685);
        _stateTaxes.put(States.NH, .0);
        _stateTaxes.put(States.NJ, .06625);
        _stateTaxes.put(States.NM, .05125);
        _stateTaxes.put(States.NY, .04);
        _stateTaxes.put(States.NC, .0475);
        _stateTaxes.put(States.ND, .05);
        _stateTaxes.put(States.OH, .0575);
        _stateTaxes.put(States.OK, .045);
        _stateTaxes.put(States.OR, .0);
        _stateTaxes.put(States.PA, .06);
        _stateTaxes.put(States.RI, .07);
        _stateTaxes.put(States.SC, .06);
        _stateTaxes.put(States.SD, .045);
        _stateTaxes.put(States.TN, .07);
        _stateTaxes.put(States.TX, .0625);
        _stateTaxes.put(States.UT, .0595);
        _stateTaxes.put(States.VT, .06);
        _stateTaxes.put(States.VA, .053);
        _stateTaxes.put(States.WA, .065);
        _stateTaxes.put(States.WV, .06);
        _stateTaxes.put(States.WI, .05);
        _stateTaxes.put(States.WY, .04);

    }

    /**
     * Allows access to the StateTaxMap
     *
     * @return the StateTaxMap
     */
    public static StateTaxMap getInstance() {
        return StateTaxMapHolder.TAXES;
    }

    /**
     * Creates the Singleton StateTaxMap
     */
    private static class StateTaxMapHolder {

        // The singleton StateTaxMap
        private static final StateTaxMap TAXES = new StateTaxMap();
    }
}
