package UI;

import ordering.Order;

/**
 *
 * @author Joe
 */
public class UIBuilder 
{
    public static Order order;
    public static boolean _isAdmin;
    public static void main(String[] args)
    {
        order = new Order();
        _isAdmin = false;
        Login login = new Login();
        login.setVisible(true);
    }
}
