package ordering;

/* 
 * Item 
 * Class that contains the name and price. 
 *
 * @author Dalton Rothenberger
 * @version November 27, 2018
 *
 */
public class Item {

    /**
     * The name of the item
     */
    private String _name;

    /**
     * The price of the item
     */
    private double _price;

    /**
     * Creates an Item object that has a name and price,
     *
     * @param name The name of the item
     * @param price The price of the item
     */
    public Item(String name, double price) {

        _name = name;
        _price = price;

    }

    /**
     * This is private so that the default constructor that Java would normally
     * create does not get created and there is no access to this constructor
     * because an item must have certain parts upon construction
     */
    private Item() {

    }

    /**
     * Allows access to the name of the item from outside the class
     *
     * @return The name of the item
     */
    public String getName() {
        return _name;
    }

    /**
     * Allows access to the price of the item from outside the class
     *
     * @return The price of the item
     */
    public double getPrice() {
        return _price;
    }

}
