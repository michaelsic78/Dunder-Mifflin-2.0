package customer;

import ordering.Order;

/**
 * Customer Class that contains the list of items on the Order
 *
 * @author Dalton Rothenberger
 * @version November 27, 2018
 *
 */
public class Customer {

    /**
     * Array List of orders the customer has
     */
    private Order _order = new Order();

    /**
     * Used to determine if the customer has employee level access
     */
    private boolean _isEmployee;

    /**
     * Constructs a Customer object and instantiates the order.
     *
     * @param isEmployee Boolean for if the customer is an employee or not
     */
    public Customer(boolean isEmployee) {
        _order = new Order();
        _isEmployee = isEmployee;
    }

    /**
     * This is private so that the default constructor that Java would normally
     * create does not get created and there is no access to this constructor
     * because a customer must have certain parts upon construction
     */
    private Customer() {

    }

    /**
     * Allows access to the orders from outside the class
     *
     * @return The ArrayList of orders for the customer
     */
    public Order getOrder() {
        return _order;
    }

}
