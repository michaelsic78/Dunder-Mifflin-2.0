package database;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;

/**
 * Class that allows access to the database table that contains the user's login
 * credentials. Allows the password to be searched for to validate user login.
 * Allows a new user's credentials to be added to the database.
 *
 * @author Dalton Rothenberger
 * @version November 30, 2018
 */
public class DB_UserInfo {

    /**
     * Allows access to the Credentials Database table and looks for the
     * password of the user
     *
     * @param username The username of the user trying to log in
     * @return The password of the user or null if an error occurred
     * @throws java.sql.SQLException
     */
    public static String getPassword(String username) throws SQLException {

        String toReturn = null;

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the password from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "SELECT [Password] FROM [Credentials] WHERE [Username] = '" + username + "'";
            rs = state.executeQuery(sql);

            // getting the password from the database
            rs.next();
            toReturn = rs.getString(1);     // the first value in getString is at 1

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

        return toReturn;
    }

    /**
     * Allows access to the Credential Database table and looks for the
     * isEmployee of the user
     *
     * @param username The username of the user trying to log in
     * @return The isEmplyee boolean of the user or null if an error occurred
     * @throws java.sql.SQLException
     */
    public static Boolean getIsEmployee(String username) throws SQLException {

        Boolean toReturn = null;

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the password from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "SELECT [isEmployee] FROM [Credentials] WHERE [Username] = '" + username + "'";
            rs = state.executeQuery(sql);

            // getting the password from the database
            rs.next();
            toReturn = rs.getBoolean(1);     // the first value in getString is at 1

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

        return toReturn;
    }

    /**
     * Allows access to the Credential Database table and adds a user to the
     * Credentials Database
     *
     * @param username The username of the user that is being created
     * @param password The password of the user that is being created
     * @throws java.sql.SQLException
     */
    public static void addUser(String username, String password, boolean isEmployee) throws SQLException {

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the password from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "INSERT INTO [Credentials](Username,Password,isEmployee) VALUES ('" + username + "','" + password + "','" + isEmployee + "')";
            state.executeUpdate(sql);

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

    }

}
