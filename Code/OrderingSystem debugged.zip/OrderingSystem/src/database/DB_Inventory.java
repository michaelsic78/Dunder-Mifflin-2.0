package database;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Class that allows access to the database table that contains the inventory
 * for items. Allows the quantity to be accessed for an item. Allows the
 * inventory level to be adjusted. Allows quantity to be subtracted from
 *
 * @author Dalton Rothenberger
 * @version November 30, 2018
 */
public class DB_Inventory {

    /**
     * Allows access to the Inventory Database table and looks for the quantity
     * of the item
     *
     * @param itemName The name of the item that's quantity is supposed to be
     * checked
     * @return The quantity of the item or null if an error occurred
     * @throws java.sql.SQLException
     */
    public static Integer getQuantity(String itemName) throws SQLException {

        Integer toReturn = null;

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the quantity from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "SELECT [Quantity] FROM [Inventory] WHERE [ItemName] = '" + itemName + "'";
            rs = state.executeQuery(sql);

            // getting the quantity from the result set
            rs.next();
            toReturn = rs.getInt(1);    // the first value in getInt is at 1

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

        return toReturn;
    }

    /**
     * Allows access to the Inventory Database table and looks for the quantity
     * of the item and subtracts the amount given
     *
     * @param itemName The name of the item that's quantity is supposed to be
     * checked
     * @param amount The amount supposed to be subtracted from the quantity
     * @throws java.sql.SQLException
     */
    public static void subtractQuantity(String itemName, int amount) throws SQLException {

        // Thew new quantity that will be put into the table 
        // after the subtraction is done
        int newQuantity;

        // The old quantity before the subtraction occurred
        int oldQuantity;

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the quantity from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "SELECT [Quantity] FROM [Inventory] WHERE [ItemName] = '" + itemName + "'";
            rs = state.executeQuery(sql);

            // getting the quantity from the result set
            rs.next();
            oldQuantity = rs.getInt(1);     // the first value in getInt is at 1

            newQuantity = oldQuantity - amount;

            sql = "UPDATE [Inventory] SET [Quantity] = '" + newQuantity + "' WHERE [ItemName] = '" + itemName + "'";

            state.executeUpdate(sql);

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

    }

    /**
     * Allows access to the Inventory Database table and looks for the quantity
     * of the item and writes the amount there
     *
     * @param itemName The name of the item that's quantity is supposed to be
     * checked
     * @param amount The amount supposed to be subtracted from the quantity
     * @throws java.sql.SQLException
     */
    public static void adjustInventory(String itemName, int amount) throws SQLException {

        // Creating the relative path to the database
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString();
        s += "\\src\\database\\DMDatabase.accdb";

        // The connection to the database
        Connection conn = null;

        // The sql statement used to access the database
        Statement state = null;

        // The result set that is returned from the sql statement
        ResultSet rs = null;

        // String that holds the sql command
        String sql;

        try {

            // getting the quantity from the database
            conn = DriverManager.getConnection("jdbc:ucanaccess://" + s);
            state = conn.createStatement();
            sql = "UPDATE [Inventory] SET [Quantity] = '" + amount + "' WHERE [ItemName] = '" + itemName + "'";
            state.executeUpdate(sql);

        } catch (SQLException ex) {
        } finally {

            if (rs != null) {
                rs.close();
            }

            if (state != null) {
                state.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

    }

}
